<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">


            </div>
            <ul class="nav navbar-nav">
                <li class="<?php echo $class == 'reg' ? 'active' : '' ?>">
                    <a href="individual_reg.php">Sign Up</a>
                </li>
                <li class="<?php echo $class != 'reg' ? 'active' : '' ?>">

                    <a href="signin.php">Sign In</a>

                <li>
                    <a href="../">Go Back</a>
                </li>
            </ul>
        </div>

    </nav>