<?php
session_start();

// Set default or fallback values silently if undefined
$_SESSION['amount'] = $_SESSION['amount'] ?? 500; // fallback to ₹500
$_SESSION['email'] = $_SESSION['user_email'] ?? ''; // fallback to empty string if not logged in
$_SESSION['booking_id'] = $_GET['loc'] ?? ''; // fallback to empty if no loc param
?>

<!DOCTYPE html>
<html>
<head>
    <title>Processing Payment...</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>

<script>
    const orderUrl = "/RailLink/create_order.php";

    fetch(orderUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
            amount: "<?= $_SESSION['amount'] ?>",
            email: "<?= $_SESSION['email'] ?>",
            booking_id: "<?= $_SESSION['booking_id'] ?>"
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            alert("Error: " + data.error);
            return;
        }

        const options = {
            "key": "rzp_test_caFGNLBg69hQxI", // Replace with your Razorpay key
            "amount": data.amount,
            "currency": data.currency,
            "name": "RailLink",
            "description": "Ticket Booking",
            "order_id": data.order_id,
            "handler": function (response) {
                fetch('/RailLink/razorpay_verify.php', {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: new URLSearchParams({
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature
                    })
                })
                .then(res => res.text())
                .then(html => {
                    document.body.innerHTML = html;
                });
            },
            "prefill": {
                "email": data.email
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        const rzp = new Razorpay(options);
        rzp.open();
    })
    .catch(err => {
        alert("Something went wrong: " + err);
    });
</script>

</body>
</html>
