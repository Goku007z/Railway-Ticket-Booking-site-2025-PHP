<?php
session_start();
require('../razorpay/Razorpay.php'); // Adjusted path
use Razorpay\Api\Api;

$keyId = 'rzp_test_caFGNLBg69hQxI';
$keySecret = '7J4gj9tDLjSKrxkaLstwhR4v';
$api = new Api($keyId, $keySecret);

// Set booking-related session data
$_SESSION['amount'] = 2525;
$_SESSION['email'] = $_SESSION['user_email'];
$_SESSION['booking_id'] = $_GET['loc'];

// Create Razorpay order
$order = $api->order->create([
    'receipt' => 'rcptid_' . rand(1000,9999),
    'amount' => $_SESSION['amount'] * 100,
    'currency' => 'INR'
]);

$_SESSION['razorpay_order_id'] = $order['id'];
?>

<form action="../razorpay_verify.php" method="POST">
<script src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?= $keyId ?>"
    data-amount="<?= $_SESSION['amount'] * 100 ?>"
    data-currency="INR"
    data-order_id="<?= $order['id'] ?>"
    data-buttontext="Pay Now"
    data-name="RailLink"
    data-description="Train Ticket Booking"
    data-prefill.email="<?= $_SESSION['email'] ?>"
    data-theme.color="#3399cc">
</script>
<input type="hidden" name="razorpay_order_id" value="<?= $order['id'] ?>">
</form>
