<?php
session_start();
require_once 'razorpay/Razorpay.php';
require_once 'conn.php'; // Your DB connection
require_once 'constants.php';

use Razorpay\Api\Api;

// Load your Razorpay credentials
$keyId = 'rzp_test_caFGNLBg69hQxI';     // Replace with your actual Razorpay key
$keySecret = '7J4gj9tDLjSKrxkaLstwhR4v';      // Replace with your actual Razorpay secret

$api = new Api($keyId, $keySecret);

if (isset($_POST['razorpay_payment_id'])) {
    try {
        // Step 1: Verify Signature
        $attributes = [
            'razorpay_order_id' => $_POST['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        ];
        $api->utility->verifyPaymentSignature($attributes);

        // Step 2: Extract details from session
        $user_id     = $_SESSION['user_id'];
        $email       = $_SESSION['email'];
        $amount      = $_SESSION['amount'];
        $schedule_id = $_SESSION['schedule'];
        $number      = $_SESSION['no'];
        $class       = $_SESSION['class'];
        $original    = $_SESSION['original'];
        $ref         = $_POST['razorpay_payment_id'];
        $code        = genCode($schedule_id, $user_id, $class);
        $seat        = genSeat($schedule_id, $class, $number);

        // Step 3: Insert payment record
        $conn->query("INSERT INTO payment (passenger_id, schedule_id, amount, ref, date) VALUES ('$user_id', '$schedule_id', '$original', '$ref', NOW())");
        $payment_id = $conn->insert_id;

        // Step 4: Book ticket
        if ($payment_id > 0) {
            $conn->query("INSERT INTO booked (payment_id, schedule_id, user_id, code, class, no, date, seat) VALUES ('$payment_id', '$schedule_id', '$user_id', '$code', '$class', '$number', NOW(), '$seat')");

            // Clear used session data
            unset($_SESSION['discount']);
            unset($_SESSION['amount']);
            unset($_SESSION['original']);
            unset($_SESSION['schedule']);
            unset($_SESSION['no']);
            unset($_SESSION['class']);

            $_SESSION['pay_success'] = 'true';
            $_SESSION['has_paid'] = 'true';

            header("Location: pro/individual.php?page=paid&now=true");
            exit;
        } else {
            throw new Exception("Payment saved but booking failed.");
        }

    } catch (Exception $e) {
        echo "<h3 style='color:red;'>❌ Verification failed: " . $e->getMessage() . "</h3>";
        echo "<p><a href='pro/individual.php?page=pay'>← Go back to payment</a></p>";
    }
} else {
    echo "<h3 style='color:red;'>❌ No payment ID received.</h3>";
}
