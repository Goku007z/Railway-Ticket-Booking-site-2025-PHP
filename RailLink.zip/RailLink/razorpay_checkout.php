<?php
session_start();
$order_id = $_SESSION['razorpay_order_id'];
$amount = $_SESSION['amount'] * 100;
$email = $_SESSION['email'];
?>

<form action="razorpay_verify.php" method="POST">
<script src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="YOUR_KEY_ID"
    data-amount="<?= $amount ?>"
    data-currency="INR"
    data-order_id="<?= $order_id ?>"
    data-buttontext="Pay Now"
    data-name="RailLink"
    data-description="Train Ticket"
    data-prefill.email="<?= $email ?>"
    data-theme.color="#3399cc">
</script>
<input type="hidden" name="razorpay_order_id" value="<?= $order_id ?>">
</form>
