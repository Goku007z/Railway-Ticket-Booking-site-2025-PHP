<?php
session_start();
require('razorpay/Razorpay.php'); // Make sure path is correct
use Razorpay\Api\Api;

// Razorpay credentials
$keyId = 'rzp_test_caFGNLBg69hQxI';
$keySecret = '7J4gj9tDLjSKrxkaLstwhR4v';

$api = new Api($keyId, $keySecret);

// Get amount and other data from POST or fallback to session
$amount = isset($_POST['amount']) ? (int)$_POST['amount'] * 100 : (int)$_SESSION['amount'] * 100;
$email = $_POST['email'] ?? $_SESSION['email'];
$booking_id = $_POST['booking_id'] ?? $_SESSION['booking_id'];

try {
    // Create Razorpay order
    $order = $api->order->create([
        'receipt' => 'rcptid_' . rand(1000, 9999),
        'amount' => $amount,
        'currency' => 'INR',
        'payment_capture' => 1
    ]);

    // Save order ID in session
    $_SESSION['razorpay_order_id'] = $order['id'];

    // Respond with order details
    header('Content-Type: application/json');
    echo json_encode([
        'order_id' => $order['id'],
        'amount' => $amount,
        'currency' => 'INR',
        'email' => $email,
        'booking_id' => $booking_id
    ]);

} catch (Exception $e) {
    // Return error to front-end for debugging
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}
