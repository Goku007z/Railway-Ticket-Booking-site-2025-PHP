<?php include 'constants.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Terms of Use - <?php echo @$title; ?></title>
    <link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <nav class="nim-menu navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php"><?php echo $title[0]; ?><span class="themecolor"><?php echo $title[1]; ?></span><?php for ($i = 2; $i < strlen($title); $i++) echo $title[$i]; ?></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php#home"><h3>Home</h3></a></li>
                        <li><a href="index.php#two"><h3>About</h3></a></li>
                        <li><a href="library/sample.pdf"><h3>Map</h3></a></li>
                        <li><a href="pro/signin.php"><h3>Passenger Portal</h3></a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <section class="main-heading" id="home">
            <div class="overlay">
                <div class="container text-center">
                    <h1 class="main-heading-title">PRIVACY POLICY</h1>
                    <p class="main-heading-text">This page outlines the privacy policy for Indian Railway passengers using the RailLink e-ticketing platform.</p>
                    <div class="text-left" style="max-width: 900px; margin: 0 auto; color: #fff;">
                        <ul style="line-height: 1.8;">
                            <li>Passengers must carry a valid government-issued ID during travel.</li>
                            <li>Tickets once booked are non-refundable unless specified otherwise.</li>
                            <li>Misuse of booking portal or fraudulent activity will result in account suspension.</li>
                            <li>E-tickets must be presented digitally or in printed form when requested.</li>
                            <li>The system must not be used for illegal or bulk booking for resale.</li>
                            <li>Indian Railways reserves the right to update terms without prior notice.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <footer class="site-footer text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-4"><p class="footer-links"><a href="terms_of_use.php">Terms of Use</a> <a href="privacy_policy.php">Privacy Policy</a></p></div>
                    <div class="col-md-4"><small>&copy; <?php echo date('Y'); ?> RailLink | Developed by SITM Team</small></div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>
